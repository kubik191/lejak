"""
Copy hydrological point layers into Hydrologia_SK_doplnenie.

Replaces the QGIS workflow: zoom to a source feature, add a point in
Doplnenie at the same place, then copy attributes.

Sources (per model folder, usually Hydrological_data):
  Qn.shp                  -> Druh_bodu = prietok, with Qmax_*
  Gauge_Refrence_Level    -> Druh_bodu = QH, F0_vodočt -> nula_vodoc
  Rating_Curves           -> not copied as points (same places as gauges);
                             Excel merne krivky are used for H_Q* instead
  Waves                   -> Druh_bodu = "vlna Q10 Q100 ..." (one label per wave
                             referenced in the Q10/Q100/... columns); Qmax_N is
                             the peak of the matching Waves_*.xls file

Used by the QGIS plugin and by the command line wrapper
(hydro_automation/import_to_doplnenie.py).
"""

from __future__ import annotations

import csv
import math
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path

import fiona
import pandas as pd
from fiona.crs import from_epsg
from fiona.transform import transform as transform_xy

SOURCE_LAYERS = ("Qn", "Gauge_Refrence_Level", "Rating_Curves", "Waves")
IGNORE_DATE_FIELDS = ("Geodesy_st",)

# Wave points in Doplnenie are often placed by hand next to the gauge and named
# after the reservoir/profile from the wave sheet, so match them by river + distance.
WAVE_MATCH_RADIUS_M = 250.0
WAVE_FIELD_RE = re.compile(r"^Q(\d+)(_\w+)?$", re.IGNORECASE)

EXPLICIT_MAP = {
    "tok": ("Tok", "tok"),
    "profil": ("Profil", "profil"),
    "rkm_DHI": ("rkm", "rkm_DHI"),
    "A_Povodia": ("Plocha_pov", "A_Povodia"),
    "Hydrolog_C": ("hydro_cisl", "hydro_cislo", "Hydrolog_C"),
    "Presnost": ("tr_spolah", "Presnost"),
    "nula_vodoc": ("F0_vodočt", "F0_vodoc", "F0_vodočt", "nula_vodoc"),
}

QMAX_TO_H = {
    "Qmax_5": "H_Q5",
    "Qmax_10": "H_Q10",
    "Qmax_20": "H_Q20",
    "Qmax_50": "H_Q50",
    "Qmax_100": "H_Q100",
    "Qmax_1000": "H_Q1000",
}

VYBREZUJE = "vybrežuje"


def norm_text(value) -> str:
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return ""
    return str(value).strip()


def fold_key(value) -> str:
    return " ".join(norm_text(value).lower().split())


def fold_druh(value) -> str:
    text = fold_key(value)
    if text in {"prieotk", "prietoky"}:
        return "prietok"
    return text


def is_missing(value) -> bool:
    if value is None:
        return True
    if isinstance(value, float) and math.isnan(value):
        return True
    if isinstance(value, str) and value.strip() == "":
        return True
    return False


def get_prop(props: dict, *names):
    folded = {fold_key(k): v for k, v in props.items()}
    for name in names:
        if name in props and not is_missing(props[name]):
            return props[name]
        key = fold_key(name)
        if key in folded and not is_missing(folded[key]):
            return folded[key]
    for name in names:
        if name in props:
            return props[name]
        key = fold_key(name)
        if key in folded:
            return folded[key]
    return None


def parse_number(value):
    if is_missing(value):
        return None
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return float(value)
    text = str(value).strip().replace(" ", "").replace(",", ".")
    try:
        return float(text)
    except ValueError:
        return None


def clip_value(value, field_type: str):
    if is_missing(value):
        return None
    kind = field_type.split(":")[0]
    if kind.startswith("str"):
        text = str(value)
        if ":" in field_type:
            width = int(field_type.split(":")[1])
            text = text[:width]
        return text
    if kind.startswith("float"):
        number = parse_number(value)
        return None if number is None else float(number)
    if kind.startswith("int"):
        number = parse_number(value)
        return None if number is None else int(round(number))
    return value


def point_coords(geom) -> tuple[float, float] | None:
    if not geom:
        return None
    if geom.get("type") == "Point":
        x, y = geom["coordinates"][:2]
        return float(x), float(y)
    if geom.get("type") == "MultiPoint" and geom.get("coordinates"):
        x, y = geom["coordinates"][0][:2]
        return float(x), float(y)
    return None


def identity_key(tok, profil, rkm, druh, xy=None) -> tuple:
    rkm_n = parse_number(rkm)
    rkm_r = round(rkm_n, 4) if rkm_n is not None else None
    xy_r = None
    if xy:
        xy_r = (round(xy[0], 1), round(xy[1], 1))
    return (fold_key(tok), fold_key(profil), rkm_r, fold_druh(druh), xy_r)


CPG_ENCODINGS = {
    "utf-8": "utf-8",
    "utf8": "utf-8",
    "65001": "utf-8",
    "1250": "cp1250",
    "ansi 1250": "cp1250",
    "1252": "cp1252",
    "ansi 1252": "cp1252",
    "iso-8859-2": "iso-8859-2",
    "88592": "iso-8859-2",
}


def shapefile_encoding(path: Path) -> str | None:
    # QGIS sets SHAPE_ENCODING="" for GDAL, so without an explicit encoding
    # fiona inside QGIS returns mis-decoded text (e.g. "VarÃ­nka").
    for suffix in (".cpg", ".CPG"):
        cpg = path.with_suffix(suffix)
        if cpg.exists():
            text = cpg.read_text(encoding="ascii", errors="ignore").strip().lower()
            return CPG_ENCODINGS.get(text, text or None)
    return None


def read_features(path: Path) -> tuple[list[dict], dict, object]:
    ignore = []
    encoding = shapefile_encoding(path) if path.suffix.lower() == ".shp" else None
    open_kwargs = {"encoding": encoding} if encoding else {}
    with fiona.open(path, **open_kwargs) as src:
        schema = src.schema
        crs = src.crs
        for name in IGNORE_DATE_FIELDS:
            if name in schema.get("properties", {}):
                ignore.append(name)
    kwargs = dict(open_kwargs)
    if ignore:
        kwargs["ignore_fields"] = ignore
    with fiona.open(path, **kwargs) as src:
        features = []
        for feat in src:
            features.append(
                {
                    "geometry": feat.get("geometry"),
                    "properties": dict(feat.get("properties") or {}),
                }
            )
        return features, src.schema, src.crs


def discover_source_dirs(roots: list[Path]) -> list[Path]:
    found = []
    seen = set()
    for root in roots:
        root = root.resolve()
        if not root.exists():
            continue
        candidates = []
        if root.is_file() and root.suffix.lower() == ".shp":
            candidates.append(root.parent)
        elif (root / "Qn.shp").exists() or (root / "Gauge_Refrence_Level.shp").exists():
            candidates.append(root)
        else:
            for shp in root.rglob("Qn.shp"):
                candidates.append(shp.parent)
            for shp in root.rglob("Gauge_Refrence_Level.shp"):
                candidates.append(shp.parent)
        for folder in candidates:
            key = str(folder.resolve()).lower()
            if key not in seen:
                seen.add(key)
                found.append(folder.resolve())
    return found


def load_rating_curves(folder: Path) -> dict[str, pd.DataFrame]:
    curves = {}
    for path in sorted(folder.glob("*.xls.xlsx")) + sorted(folder.glob("*.xlsx")):
        if path.name.startswith("~"):
            continue
        try:
            xl = pd.ExcelFile(path)
        except Exception as exc:
            print(f"warning: could not read {path.name}: {exc}", file=sys.stderr)
            continue
        for sheet in xl.sheet_names:
            df = pd.read_excel(path, sheet_name=sheet, header=None)
            parsed = parse_curve_sheet(df)
            if parsed is None or parsed.empty:
                continue
            curves[str(sheet).strip()] = parsed
    return curves


def parse_curve_sheet(df: pd.DataFrame) -> pd.DataFrame | None:
    header_row = None
    for i, row in df.iterrows():
        cells = [norm_text(v).lower() for v in row.tolist()]
        joined = " ".join(cells)
        if "h abs" in joined and any(c == "q" or c.startswith("q") for c in cells):
            header_row = i
            break
        if "h abs" in joined:
            header_row = i
            break
    if header_row is None:
        return None
    header = [norm_text(v).lower() for v in df.iloc[header_row].tolist()]
    h_col = q_col = None
    for idx, name in enumerate(header):
        if name == "h" or name.startswith("h ["):
            h_col = idx
        if name.startswith("h abs"):
            pass
        if name == "q" or name.startswith("q ["):
            q_col = idx
    if h_col is None:
        h_col = 1 if df.shape[1] > 1 else 0
    if q_col is None:
        q_col = 3 if df.shape[1] > 3 else df.shape[1] - 1
    start = header_row + 1
    if start < len(df):
        units = [norm_text(v).lower() for v in df.iloc[start].tolist()]
        if any("[cm]" in u or "[m3" in u or "m n.m" in u for u in units):
            start += 1
    block = df.iloc[start:, [h_col, q_col]].copy()
    block.columns = ["H_cm", "Q"]
    block["H_cm"] = block["H_cm"].map(parse_number)
    block["Q"] = block["Q"].map(parse_number)
    block = block.dropna(subset=["H_cm", "Q"]).sort_values("Q")
    if block.empty:
        return None
    return block.reset_index(drop=True)


def lookup_h(curve: pd.DataFrame, q: float) -> str | None:
    if curve is None or curve.empty or q is None:
        return None
    q_min = float(curve["Q"].iloc[0])
    q_max = float(curve["Q"].iloc[-1])
    if q > q_max + 1e-6:
        return VYBREZUJE
    if q <= q_min:
        h = float(curve["H_cm"].iloc[0])
        return format_h(h)
    qs = curve["Q"].to_numpy(dtype=float)
    hs = curve["H_cm"].to_numpy(dtype=float)
    for i in range(1, len(qs)):
        if q <= qs[i] or i == len(qs) - 1:
            q0, q1 = qs[i - 1], qs[i]
            h0, h1 = hs[i - 1], hs[i]
            if q1 == q0:
                return format_h(h1)
            h = h0 + (h1 - h0) * (q - q0) / (q1 - q0)
            return format_h(h)
    return format_h(float(hs[-1]))


def format_h(h: float) -> str:
    if abs(h - round(h)) < 0.05:
        return str(int(round(h)))
    return f"{h:.1f}"


def parse_wave_sheet(df: pd.DataFrame) -> dict | None:
    label = None
    peak = None
    contract_id = None
    data_start = None
    for i in range(len(df)):
        key = fold_key(df.iat[i, 0])
        value = df.iat[i, 1] if df.shape[1] > 1 else None
        if key.startswith("typ vlny"):
            match = re.search(r"Q\d+(_\w+)?", norm_text(value))
            if match:
                label = match.group(0)
        elif key.startswith("qmax"):
            peak = parse_number(value)
        elif key.startswith("id zmluva"):
            number = parse_number(value)
            contract_id = str(int(number)) if number is not None else norm_text(value)
        elif key.startswith("t [") or key == "t":
            data_start = i + 1
            break
    if data_start is not None and df.shape[1] > 1:
        flows = [parse_number(v) for v in df.iloc[data_start:, 1].tolist()]
        flows = [q for q in flows if q is not None]
        if flows and peak is None:
            peak = max(flows)
    if label is None and peak is None:
        return None
    return {"label": label, "peak": peak, "contract_id": contract_id}


def load_waves(folder: Path) -> dict[str, dict]:
    waves = {}
    for path in sorted(folder.glob("Waves_*.xls*")):
        if path.name.startswith("~"):
            continue
        try:
            xl = pd.ExcelFile(path)
        except Exception as exc:
            print(f"warning: could not read {path.name}: {exc}", file=sys.stderr)
            continue
        for sheet in xl.sheet_names:
            parsed = parse_wave_sheet(pd.read_excel(path, sheet_name=sheet, header=None))
            if parsed is None:
                continue
            stem = path.name.split(".xls")[0][len("Waves_"):]
            parsed["file"] = path.name
            waves[fold_key(stem)] = parsed
            break
    return waves


def apply_waves(props: dict, mapped: dict, waves: dict[str, dict], dest_fields: dict) -> list[str]:
    labels = []
    notes = []
    wave_fields = []
    for name, value in props.items():
        match = WAVE_FIELD_RE.match(name)
        if match and not is_missing(value):
            wave_fields.append((int(match.group(1)), name, value))
    for period, name, value in sorted(wave_fields):
        wave = waves.get(fold_key(value))
        peak = wave["peak"] if wave else parse_number(value)
        label = (wave or {}).get("label") or name
        labels.append(label)
        if wave is None and peak is None:
            notes.append(f"{name}: wave file '{value}' not found")
            continue
        qmax_field = f"Qmax_{period}"
        if qmax_field in dest_fields and peak is not None:
            mapped[qmax_field] = clip_value(peak, dest_fields[qmax_field])
            notes.append(f"{qmax_field}={peak:g}")
    mapped["Druh_bodu"] = clip_value(
        "vlna " + " ".join(labels) if labels else "vlna", dest_fields["Druh_bodu"]
    )
    return notes


def infer_druh(props: dict, layer_name: str) -> str:
    existing = get_prop(props, "Druh_bodu")
    if not is_missing(existing):
        return norm_text(existing)
    if layer_name.lower().startswith("wave"):
        return "vlna"
    f0 = get_prop(props, "F0_vodočt", "F0_vodoc", "nula_vodoc")
    if not is_missing(f0) or layer_name.lower().startswith("gauge"):
        return "QH"
    return "prietok"


def map_properties(props: dict, dest_fields: dict, layer_name: str) -> dict:
    out = {name: None for name in dest_fields}
    druh = infer_druh(props, layer_name)
    out["Druh_bodu"] = druh

    for dest_name, sources in EXPLICIT_MAP.items():
        if dest_name not in dest_fields:
            continue
        if dest_name == "nula_vodoc" and druh != "QH":
            continue
        value = get_prop(props, *sources)
        if dest_name == "Presnost" and isinstance(value, str):
            value = value.strip().rstrip(".")
        out[dest_name] = value

    for dest_name in dest_fields:
        if dest_name in ("Id", "Druh_bodu"):
            continue
        if dest_name.startswith("H_"):
            continue
        if not is_missing(out.get(dest_name)):
            continue
        if dest_name in ("Qmax_1", "Qmax_2", "Qmax_5", "Qmax_10", "Qmax_20", "Qmax_50", "Qmax_100", "Qmax_1000"):
            if druh == "QH":
                continue
        value = get_prop(props, dest_name)
        if not is_missing(value):
            out[dest_name] = value

    for name, field_type in dest_fields.items():
        out[name] = clip_value(out.get(name), field_type)
    return out


def fill_water_levels(props: dict, curve: pd.DataFrame | None, dest_fields: dict) -> list[str]:
    notes = []
    if curve is None or props.get("Druh_bodu") == "QH":
        return notes
    for q_field, h_field in QMAX_TO_H.items():
        if h_field not in dest_fields:
            continue
        q = parse_number(props.get(q_field))
        if q is None:
            continue
        h = lookup_h(curve, q)
        if h is None:
            continue
        props[h_field] = clip_value(h, dest_fields[h_field])
        notes.append(f"{h_field}={h}")
    return notes


def same_crs(a, b) -> bool:
    if not a or not b:
        return True
    try:
        epsg_a, epsg_b = a.to_epsg(), b.to_epsg()
        if epsg_a and epsg_b:
            return epsg_a == epsg_b
        return a.to_wkt() == b.to_wkt()
    except Exception:
        return str(a) == str(b)


def model_name(folder: Path, props: dict) -> str:
    model = norm_text(get_prop(props, "model_id"))
    if model:
        return model
    name = folder.name
    if name.lower() == "hydrological_data":
        name = folder.parent.name
    return name.split("-Hydrological_data")[0]


def collect_new_features(
    source_dirs: list[Path],
    dest_features: list[dict],
    dest_fields: dict,
    fill_levels: bool,
    dest_crs=None,
    progress=None,
) -> tuple[list[dict], list[dict]]:
    """Plan the import.

    Returns (planned features, report rows). Every report row for a point also
    carries "_xy" (destination CRS) and, when action == "add", "_feature".
    progress(index, total, folder) is called before each source folder.
    """
    existing_keys = set()
    existing_xy = []
    for feat in dest_features:
        props = feat["properties"]
        xy = point_coords(feat.get("geometry"))
        existing_keys.add(
            identity_key(
                props.get("tok"),
                props.get("profil"),
                props.get("rkm_DHI"),
                props.get("Druh_bodu"),
                xy,
            )
        )
        if xy:
            existing_xy.append((xy, fold_druh(props.get("Druh_bodu")), fold_key(props.get("tok")), props.get("profil")))

    planned = []
    report = []
    for index, folder in enumerate(source_dirs):
        if progress:
            progress(index, len(source_dirs), folder)
        curves = load_rating_curves(folder) if fill_levels else {}
        waves = load_waves(folder)
        for layer in SOURCE_LAYERS:
            shp = folder / f"{layer}.shp"
            if not shp.exists():
                continue
            if layer == "Rating_Curves":
                report.append(
                    {
                        "model": model_name(folder, {}),
                        "source_dir": str(folder),
                        "layer": layer,
                        "action": "skip_layer",
                        "tok": "",
                        "profil": "",
                        "rkm": "",
                        "Druh_bodu": "",
                        "note": "same stations as Gauge; Excel curves used for H_Q*",
                    }
                )
                continue
            features, _, src_crs = read_features(shp)
            reproject = not same_crs(src_crs, dest_crs)
            for feat in features:
                props = feat["properties"]
                mapped = map_properties(props, dest_fields, layer)
                wave_notes = apply_waves(props, mapped, waves, dest_fields) if layer == "Waves" else []
                xy = point_coords(feat.get("geometry"))
                if xy and reproject:
                    xs, ys = transform_xy(src_crs, dest_crs, [xy[0]], [xy[1]])
                    xy = (xs[0], ys[0])
                key = identity_key(
                    mapped.get("tok"),
                    mapped.get("profil"),
                    mapped.get("rkm_DHI"),
                    mapped.get("Druh_bodu"),
                    xy,
                )
                excel_id = get_prop(props, "EXCEL_ID", "ID_Zmluva")
                excel_key = str(int(excel_id)) if parse_number(excel_id) is not None else norm_text(excel_id)
                curve = curves.get(excel_key)
                notes = wave_notes + (fill_water_levels(mapped, curve, dest_fields) if fill_levels else [])

                action = "add"
                note = "; ".join(notes)
                druh_key = fold_druh(mapped.get("Druh_bodu"))
                tok_key = fold_key(mapped.get("tok"))
                if key in existing_keys:
                    action = "skip_existing"
                    note = (note + "; " if note else "") + "already in destination"
                elif xy:
                    for (ex, ey), druh, ex_tok, ex_profil in existing_xy:
                        dist = math.hypot(xy[0] - ex, xy[1] - ey)
                        if druh_key == druh and dist < 0.5:
                            action = "skip_existing"
                            note = (note + "; " if note else "") + "same coordinates already in destination"
                            break
                        if (
                            layer == "Waves"
                            and druh.startswith("vlna")
                            and ex_tok == tok_key
                            and dist <= WAVE_MATCH_RADIUS_M
                        ):
                            action = "skip_existing"
                            note = (note + "; " if note else "") + (
                                f"wave point already in destination {dist:.0f} m away "
                                f"('{norm_text(ex_profil)}', {druh})"
                            )
                            break

                row = {
                    "model": model_name(folder, props),
                    "source_dir": str(folder),
                    "layer": layer,
                    "action": action,
                    "tok": mapped.get("tok"),
                    "profil": mapped.get("profil"),
                    "rkm": mapped.get("rkm_DHI"),
                    "Druh_bodu": mapped.get("Druh_bodu"),
                    "note": note,
                    "_xy": xy,
                }
                report.append(row)
                if action != "add":
                    continue
                existing_keys.add(key)
                if xy:
                    existing_xy.append((xy, druh_key, tok_key, mapped.get("profil")))
                feature = {
                    "type": "Feature",
                    "geometry": {"type": "Point", "coordinates": (xy[0], xy[1])} if xy else None,
                    "properties": mapped,
                }
                row["_feature"] = feature
                planned.append(feature)
    return planned, report


def backup_shapefile(shp: Path) -> Path:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    bak_dir = shp.parent / "_backups" / stamp
    bak_dir.mkdir(parents=True, exist_ok=True)
    stem = shp.stem
    for sibling in shp.parent.glob(stem + ".*"):
        shutil.copy2(sibling, bak_dir / sibling.name)
    return bak_dir


def write_shapefile(path: Path, schema: dict, crs, features: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    for leftover in path.parent.glob(path.stem + ".*"):
        if leftover.suffix.lower() == ".xml":
            continue
        leftover.unlink()
    with fiona.open(
        path,
        "w",
        driver="ESRI Shapefile",
        schema=schema,
        crs=crs or from_epsg(5514),
        encoding="utf-8",
    ) as dst:
        for feat in features:
            dst.write(feat)
    cpg = path.with_suffix(".cpg")
    cpg.write_text("UTF-8", encoding="ascii")


REPORT_FIELDS = ["model", "source_dir", "layer", "action", "tok", "profil", "rkm", "Druh_bodu", "note"]


def write_report(path: Path, report: list[dict]) -> None:
    if not report:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=REPORT_FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(report)

